package iHoover;

/**
 * <b>Aspirateur est la classe repr�sentant un aspirateur</b>
 * <p>
 * Un aspirateur est caract�ris� par les informations suivantes :
 * <ul>
 * <li>Un abscisse, x</li>
 * <li>Un ordonn�e, y</li>
 * <li>Une orientation, N, S, E, W</li>
 * </ul>
 * </p>
 * <p>
 * De plus, un aspirateur a une r�f�rence sur la grille sur laquelle, il �volue.
 * </p>
 * 
 * @see Grille
 * 
 * @author OlivierROGER
 * @version 1.0
 */
public class Aspirateur {

	/**
	 * La position x de l'aspirateur.
	 * 
	 * @see Aspirateur#getX()
	 */
	private int x;

	/**
	 * La position y de l'aspirateur.
	 * 
	 * @see Aspirateur#getY()
	 */
	private int y;

	/**
	 * L'orientation de l'aspirateur. Elle peut avoir 4 valeurs : N, S, E, W. On
	 * aurait pu faire une �numration ; enum
	 * 
	 * @see Aspirateur#getOrientation()
	 */
	private char orientation;

	/**
	 * Les param�tres (longueur, largeur) de la grille. L'aspirateur prend en
	 * compte ces dimensions lors de ses d�placements
	 * 
	 * @see Grille#getTailleX()
	 * @see Grille#getTailleY()
	 */
	private Grille grille;

	/**
	 * Constructeur Aspirateur
	 * <p>
	 * A la construction d'un objet Aspirateur. La position x et y est fix� par
	 * rapport � la lecture de la deuxi�me ligne du fichier test.txt
	 * </p>
	 * 
	 * @param x
	 *            La position intiale x de l'aspirateur.
	 * @param y
	 *            La position initiale y de l'aspirateur.
	 * @param orientation
	 *            L'orientation intiale de l'aspirateur
	 * @param grille
	 *            La largeur et la longueur de la grille.
	 * 
	 * @see GestionAspirateur#traiterLigne2(String)
	 * @see Aspirateur#getX
	 * @see Aspirateur#getY
	 */
	public Aspirateur(int x, int y, char orientation, Grille grille) {
		this.x = x;
		this.y = y;
		this.orientation = orientation;
		this.grille = grille;
	}

	/**
	 * Avance l'aspirateur d'une case en fonction de son orientation.
	 * L'aspirateur regarde la tailleX et la tailleY de la grille. 
	 * Si l'aspirateur d�passe tailleX ou tailleY, celui-ci n'avance pas.
	 * 
	 * @see Grille#getTailleX
	 * @see Grille#getTailleY
	 * @see GestionAspirateur#traiterLigne3(String)
	 */
	public void avancer() {
		switch (orientation) {
		case 'N':
			if (y < grille.getTailleY()) {
				y = (y + 1);
			}
			break;
		case 'S':
			if (y > 0) {
				y = (y - 1);
			}
			break;
		case 'W':
			if (x > 0) {
				x = (x - 1);
			}
			break;
		case 'E':
			if (x < grille.getTailleX()) {
				x = (x + 1);
			}
			break;
		default:
			System.out.println("Dysfonctionnement Lettre d'Orientation");
		}
	}

	/**
	 * L'aspirateur tourne � gauche. 
	 * L'orientation change en fonction de sa pr�c�dente orientation.
	 * 
	 * @see Aspirateur#orientation
	 */
	public void tournerGauche() {
		switch (orientation) {
		case 'N':
			orientation = 'W';
			break;
		case 'W':
			orientation = 'S';
			break;
		case 'S':
			orientation = 'E';
			break;
		case 'E':
			orientation = 'N';
			break;
		default:
			System.out.println("Dysfonctionnement Lettre d'Orientation");
		}
	}

	/**
	 * L'aspirateur tourne � droite. 
	 * L'orientation change en fonction de sa pr�c�dente orientation.
	 * 
	 * @see Aspirateur#orientation
	 */
	public void tournerDroite() {
		switch (orientation) {
		case 'W':
			orientation = 'N';
			break;
		case 'S':
			orientation = 'W';
			break;
		case 'E':
			orientation = 'S';
			break;
		case 'N':
			orientation = 'E';
			break;
		default:
			System.out.println("Dysfonctionnement Lettre d'Orientation");
		}
	}

	/**
	 * Retourne la position x de l'aspirateur.
	 * 
	 * @return L'abscisse de l'aspirateur.
	 */
	public int getX() {
		return x;
	}

	/**
	 * Retourne la position y de l'aspirateur.
	 * 
	 * @return L'ordonn�e de l'aspirateur.
	 */
	public int getY() {
		return y;
	}

	/**
	 * Retourne l'orientation de l'aspirateur.
	 * 
	 * @return L'orientation de l'aspirateur.
	 */
	public char getOrientation() {
		return orientation;
	}
}