package iHoover;

/**
 * <b>La grille est une classe repr�sentant un espace</b>
 * <p>
 * Une grille est caract�ris� par les informations suivantes :
 * <ul>
 * <li>Un abscisse</li>
 * <li>Un ordonn�e</li>
 * <li></li>
 * </ul>
 * </p>
 * <p>
 * Une grille poss�de deux tailles statiques. Ces tailles vont de 0 � la valeur
 * max. Grille(0 -> X);(0 -> Y)
 * </p>
 * 
 * @author OlivierROGER
 * @version 1.0
 */
public class Grille {

	/**
	 * La tailleX de la grille. Cette tailleX n'est pas modifiable.
	 * 
	 * @see Grille#getTailleX()
	 */
	private int tailleX;

	/**
	 * La tailleX de la grille. Cette tailleX n'est pas modifiable.
	 * 
	 * @see Grille#getTailleY()
	 */
	private int tailleY;

	/**
	 * Constructeur Grille
	 * <p>
	 * A la construction d'un objet Grille. La longueur et la largeur est fix�
	 * par rapport � la lecture de la premi�re ligne du fichier test.txt
	 * </p>
	 * 
	 * @param tailleX
	 *            La longueur de la grille.
	 * @param tailleY
	 *            La largeur de la grille.
	 * 
	 * @see GestionAspirateur#traiterLigne1(String)
	 * @see Grille#getTailleX
	 * @see Grille#getTailleY
	 */
	public Grille(int tailleX, int tailleY) {
		this.tailleX = tailleX;
		this.tailleY = tailleY;
	}

	/**
	 * Retourne la tailleX de la grille.
	 * 
	 * @return La longueur de la grille.
	 */
	public int getTailleX() {
		return tailleX;
	}

	/**
	 * Retourne la tailleY de la grille.
	 * 
	 * @return La largeur de la grille.
	 */
	public int getTailleY() {
		return tailleY;
	}

}