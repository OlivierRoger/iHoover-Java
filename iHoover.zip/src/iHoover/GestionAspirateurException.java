package iHoover;

public class GestionAspirateurException extends Exception {

	/**
	 * Constructeur GestionApirateurException
	 * <p>
	 * A la construction d'un objet GestionAspirateurException. Les m�thodes de
	 * cette classe sont similaires � celle de l'objet Exception
	 * </p>
	 * 
	 * @seen {@link Exception()}
	 */
	public GestionAspirateurException() {
		super();
	}

	/**
	 * Constructeur GestionApirateurException
	 * <p>
	 * A la construction d'un objet GestionAspirateurException. Les m�thodes de
	 * cette classe sont similaires � celle de l'objet Exception
	 * </p>
	 * 
	 * @seen {@link Exception#getMessage()}
	 */
	public GestionAspirateurException(String message) {
		super(message);
	}
}
