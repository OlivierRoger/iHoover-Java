package iHoover;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GestionAspirateur {

	// Cr�ation des objets utilis�s dans GestionAspirateur
	private static Grille grille = null;
	private static Aspirateur aspirateur = null;

	/**
	 * La fonction main lit un fichier test.txt
	 * 
	 * @throws GestionAspirateurException,
	 *             Si la ligne n'existe pas
	 *
	 * 			@try, @catch FileInputStream -> Trouve aucun fichier fichier.
	 *             Si scanner est en lecture dans fis, on le ferme. 
	 *             Si le fichier est ouvert on le ferme.
	 * 
	 */
	public static void main(String[] args) {
		// FONCTION QUI LIT LE FICHIER
		// Cr�ation des objets utilis�s dans le main
		FileInputStream fis = null;
		Scanner scanner = null;
		try {
			// l'objet fis va lire le fichier
			fis = new FileInputStream(new File("test.txt"));
			scanner = new Scanner(fis);
			// l'objet scanner est utilis� ici, pour lire ligne par ligne
			// Aller � la prochaine ligne -> LINE 1
			if (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				traiterLigne1(line);
			} else {
				throw new GestionAspirateurException("Pas de ligne 1");
			}
			// Aller � la prochaine ligne -> LINE 2
			if (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				traiterLigne2(line);
			} else {
				throw new GestionAspirateurException("Pas de ligne 2");
			}
			// Aller � la prochaine ligne -> LINE 3
			if (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				traiterLigne3(line);
			} else {
				throw new GestionAspirateurException("Pas de ligne 3");
			}
		} catch (FileNotFoundException e) {
			// Cette exception est lev�e si l'objet FileInputStream ne trouve ;
			// aucun fichier
			System.out.println("Pas de fichier trouv�");
		} catch (GestionAspirateurException e) {
			System.out.println(e.getMessage());
		} finally {
			if (scanner != null) {
				scanner.close();
			}
			// On ferme nos flux de donn�es dans un bloc finally pour s'assurer
			// que ces instructions seront ex�cut�es dans tous les cas m�me si
			// une exception est lev�e !
			try {
				if (fis != null)
					fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * traiterLigne1 va s�lectionner les bonnes occurences dans la chaine avec
	 * une regex
	 * 
	 * @throws, est renvoy� lorsque le pattern cherch� ne correspond pas La
	 * ligne1 du fichier doit �tre de la forme : |Nombre Nombre|
	 */
	static void traiterLigne1(String line) throws GestionAspirateurException {

		// Expression r�guli�re pour valider le format de la premi�re ligne
		Pattern pattern = Pattern.compile("^([1-9][0-9]*) ([1-9][0-9]*)$");
		Matcher matcher = pattern.matcher(line);

		if (matcher.find()) {
			int grilleX = Integer.parseInt(matcher.group(1));
			int grilleY = Integer.parseInt(matcher.group(2));
			// Construction de l'objet avec les param�tres initiaux
			grille = new Grille(grilleX, grilleY);
		} else {
			throw new GestionAspirateurException("Ligne 1 mal format�e");
		}
	}

	/**
	 * traiterLigne2 va s�lectionner les bonnes occurences dans la chaine avec
	 * une regex
	 * 
	 * @throws, est renvoy� lorsque le pattern cherch� ne correspond pas. La
	 * ligne2 du fichier doit �tre de la forme : |Nombre Nombre Orientation|
	 */
	static void traiterLigne2(String line) throws GestionAspirateurException {
		// Expression r�guli�re pour valider le format de la deuxi�me ligne
		Pattern pattern = Pattern.compile("^([1-9][0-9]*) ([1-9][0-9]*) ([NWES])$");
		Matcher matcher = pattern.matcher(line);

		if (matcher.find()) {
			int aspirateurX = Integer.parseInt(matcher.group(1));
			int aspirateurY = Integer.parseInt(matcher.group(2));
			char orientation = matcher.group(3).charAt(0);
			// Construction de l'objet avec les param�tres initiaux
			aspirateur = new Aspirateur(aspirateurX, aspirateurY, orientation, grille);
		} else {
			throw new GestionAspirateurException("Ligne 2 mal format�e");
		}
	}

	/**
	 * traiterLigne3 va s�lectionner les bonnes occurences dans la chaine avec
	 * une regex
	 * 
	 * @throws, est renvoy� lorsque le pattern cherch� ne correspond pas La
	 * ligne3 du fichier doit �tre de la forme : |SuccessionDeChar| 'A''D''G'
	 */
	static void traiterLigne3(String line) throws GestionAspirateurException {
		// Expression r�guli�re pour valider le format de la troisi�me ligne
		Pattern pattern = Pattern.compile("^[DAG]*$");
		Matcher matcher = pattern.matcher(line);

		if (matcher.find()) {
			String listInstruction = matcher.group(0);

			for (int i = 0; i < listInstruction.length(); ++i) {
				switch (listInstruction.charAt(i)) {
				case 'D':
					aspirateur.tournerDroite();
					break;
				case 'G':
					aspirateur.tournerGauche();
					break;
				case 'A':
					aspirateur.avancer();
					break;
				}

			}
			// On affiche le r�sultat de la nouvelle position de l'aspirateur
			System.out.println("La nouvelle position de l'aspirateur est : " + aspirateur.getX() + " "
					+ aspirateur.getY() + " " + aspirateur.getOrientation());
		} else {
			throw new GestionAspirateurException("Ligne 3 mal format�e");
		}
	}
}